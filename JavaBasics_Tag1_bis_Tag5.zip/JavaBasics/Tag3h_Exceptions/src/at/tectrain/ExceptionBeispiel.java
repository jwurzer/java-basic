package at.tectrain;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ExceptionBeispiel {

    static void demo1() {
        Scanner eingabe = new Scanner(System.in);

        try {
            double nummer = eingabe.nextDouble();
            System.out.println("Eingabe war: " + nummer);
            //return; // selbst bei einem return wuerde noch zuvor der finally block ausgefuehrt werden.
        }
        catch (InputMismatchException e) {
            e.printStackTrace();
            //e.printStackTrace(System.out);
        }
        catch (NoSuchElementException | IllegalStateException e) {
            // NoSuchElementException: z.b. ausgeloest mit STRG+D zum Schliessen des Standard Inputs
            e.printStackTrace(System.out);
        }
        finally {
            // wird meistens dazu verwendet um Resourcen zu schliessen
            System.out.println("WIRD IMMER AUSGEFUEHRT!");
            eingabe.close();
        }
    }

    static void demo2() {

        // try with resources: syntax: try (hier resource anlegen) {...}
        // resource (z.B. hier der Scanner) muss AutoCloseable implementiert haben.
        // Nur dann kann ich ihn bei try () anlegen.
        // hier wird garantiert, dass close() aufgerufen wird
        try (Scanner eingabe = new Scanner(System.in)) {

            double nummer = eingabe.nextDouble();
            System.out.println("Eingabe war: " + nummer);
            //return; // selbst bei einem return wuerde noch zuvor der finally block ausgefuehrt werden.
        }
        catch (InputMismatchException e) {
            e.printStackTrace();
            //e.printStackTrace(System.out);
        }
        catch (NoSuchElementException | IllegalStateException e) {
            // NoSuchElementException: z.b. ausgeloest mit STRG+D zum Schliessen des Standard Inputs
            e.printStackTrace(System.out);
        }
    }

    public static void main(String[] args) {

        //demo1();

        demo2();


        System.out.println("Good bye!!!!");
    }
}
