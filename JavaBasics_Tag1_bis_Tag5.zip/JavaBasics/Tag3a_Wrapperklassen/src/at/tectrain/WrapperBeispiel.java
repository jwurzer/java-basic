package at.tectrain;

public class WrapperBeispiel {

    public static void main(String[] args) {

        float x = 3.5f;
        if (Float.isNaN(x)) {
            System.out.println("is NaN");
        }

        //Float x1 = new Float(3.7f);
        Float x1 = Float.valueOf(3.7f);
        Float x2 = 3.7f; // autoboxing. benoetigt kein Float.valueOf(3.7f);

        float x3 = x2; // unboxing. funktioniert automatisch
        float x4 = x2.floatValue();

        String input = "3.7";

        float x5 = Float.parseFloat(input);
        Float x6 = Float.valueOf(input);

        Integer i1 = 7;
        Integer i2 = new Integer(7);
        Integer i3 = Integer.valueOf("7");

        if (i1 == i2) {
            System.out.println("i1 u i2, ein und das selbe objekt");
        }
        if (i1 == i3) {
            System.out.println("i1 u i3, ein und das selbe objekt");
        }

        // bitte immer mit equals() vergleichen
        if (i1.equals(i2)) {
            System.out.println("Inhalt ist gleich");
        }
    }
}
