package at.tectrain.geometrie;

public class Kreis extends Geometrie {
    private double radius;

    public Kreis(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public double umfang() {
        return (radius + radius) * Math.PI;
    }

    @Override
    public double flaeche() {
        return radius * radius * Math.PI;
    }

    @Override
    public String toString() {
        return "Kreis{" +
                "radius=" + radius +
                '}';
    }
}
