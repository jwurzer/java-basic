package at.tectrain;

import at.tectrain.uhr.Uhr;
import at.tectrain.uhr.UhrenFilter;

public class LambdaBeispiel {
    public static void main(String[] args) {
        Uhr u1 = new Uhr(9, 40);
        Uhr u2 = new Uhr(12, 20);

        //UhrenFilter filterNach12 = new IstNach12Uhr();

        // anonyme Klasse. wird hier deklariert und ein objekt davon erzeugt.
        // diese anonyme Klasse implement das Interface UhrenFilter.
        UhrenFilter filterNach12 = new UhrenFilter() {
            @Override
            public boolean isTrueFor(Uhr uhr) {
                return uhr.getStunde() > 12 ||
                        (uhr.getStunde() == 12 && uhr.getMinute() > 0);
            }
        };


        if (filterNach12.isTrueFor(u2)) {
            System.out.println("Es ist nach 12!");
        }

        // anonyme klasse
//        UhrenFilter arbeitszeit = new UhrenFilter() {
//            @Override
//            public boolean isTrueFor(Uhr uhr) {
//                return uhr.getStunde() >= 9 && uhr.getStunde() < 17;
//            }
//        };

        // lambda expression implementiert hier das Uhrenfilter interface
//        UhrenFilter arbeitszeit = (Uhr uhr) -> {
//            return uhr.getStunde() >= 9 && uhr.getStunde() < 17;
//        };

        // vereinfacht
//        UhrenFilter arbeitszeit =
//                (uhr) -> uhr.getStunde() >= 9 && uhr.getStunde() < 17;

        // nochmal vereinfacht
        UhrenFilter arbeitszeit =
                uhr -> uhr.getStunde() >= 9 && uhr.getStunde() < 17;


        if (arbeitszeit.isTrueFor(u1)) {
            System.out.println("Es ist arbeitszeit");
        }


        // ob die stunde 10 anzeigt
        UhrenFilter stundeIst10 = u -> u.getStunde() == 10;

        if (stundeIst10.isTrueFor(u1)) {
            System.out.println("stunde zeigt auf 10");
        }
    }
}
