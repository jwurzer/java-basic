package at.tectrain.verzweigung;

import java.util.Scanner;

public class SwitchBsp {

    public static void main(String[] args) {

        int schulnote;
        Scanner eingabe = new Scanner(System.in);

        System.out.println("Note bitte eingeben:");
        schulnote = eingabe.nextInt();

        // switch anweisung

        System.out.println("==== Erste Ausgabe ====");

        switch (schulnote) {
            case 1:
                System.out.println("Sehr gut");
                break;
            case 2:
                System.out.println("Gut");
                break;
            case 3:
                System.out.println("Befriedigend");
                break;
            case 4:
            case 5:
                System.out.println("Eine schlechte note");
                break;
            default:
                System.out.println(schulnote + " ist keine gueltige Note");
                break;
        }

        // switch anweisung (neue syntax)
        System.out.println("==== Zweite Ausgabe ====");

        switch (schulnote) {
            case 1 -> System.out.println("Sehr gut");
            case 2 -> System.out.println("Gut");
            case 3 -> System.out.println("Befriedigend");
            case 4, 5 -> System.out.println("Eine schlechte note");
            default -> System.out.println(schulnote + " ist keine gueltige Note");
        }

        // bsp: moechte die note als text in einem string speichern
        String noteAlsText;
        switch (schulnote) {
            case 1 -> noteAlsText = "Sehr gut";
            case 2 -> noteAlsText = "Gut";
            case 3 -> noteAlsText = "Befriedigend";
            case 4, 5 -> noteAlsText = "Eine schlechte note";
            default -> noteAlsText = schulnote + " ist keine gueltige Note";
        }

        // switch expression wird noteAlsText2 zugewissen.
        String noteAlsText2 =
        switch (schulnote) {
            case 1 -> "Sehr gut";
            case 2 -> "Gut";
            case 3 -> "Befriedigend";
            case 4, 5 -> "Eine schlechte note";
            default -> schulnote + " ist keine gueltige Note";
        }; // wird benoetigt fuer die anweisung

        String noteAlsText3 =
        switch (schulnote) {
            case 1 -> {
                System.out.println("SEHR!!!!!!! GUT!!!!!!!!");
                yield "Sehr gut";
            }
            case 2 -> "Gut";
            case 3 -> "Befriedigend";
            case 4, 5 -> "Eine schlechte note";
            default -> schulnote + " ist keine gueltige Note";
        }; // wird benoetigt fuer die anweisung

        System.out.println("note als text3: " + noteAlsText3);
        System.out.println("Good bye!");
    }
}
