package at.tectrain.schleifen;

import java.util.Scanner;

public class Temperatur {
    public static void main(String[] args) {

        // 1) Abfrage, wieviele Werte generiert werden sollen
        // 2) Mittelwert berechnen
        // 3) Mittelwert ausgeben

        Scanner eingabe = new Scanner(System.in);
        System.out.println("Bitte Anzahl der Temperaturwerte angeben: ");
        int anzahl = eingabe.nextInt();

        double [] werte = new double[anzahl];

        System.out.println("==== Erste Ausgabe =====");
        // for-each schleife
        for (double temp : werte) {
            //temp = 7.0; // haette keine auswirkungen auf die werte des arrays
            System.out.println("temperatur " + temp);
        }


        for (int i = 0; i < werte.length; ++i) {
            // Math.random() liefert einen Wert zw 0.0 und 1.0
            // wert zw -10.0 (inkl) und +20.0 (excl)
            werte[i] = Math.random() * 30.0 - 10.0;
        }

        System.out.println("==== Zweite Ausgabe =====");
        // for-each schleife
        double sum = 0.0f;
        for (double temp : werte) {
            //temp = 7.0; // haette keine auswirkungen auf die werte des arrays
            System.out.println("temperatur " + temp);
            sum += temp;
        }

        // der (double) cast waere hier nicht notwendig.
        //double durchschnitt = sum / (double)werte.length;
        double durchschnitt = sum / werte.length;

        System.out.println("durchschnitt " + durchschnitt);
    }
}
