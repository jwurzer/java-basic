package at.tectrain.set;

import java.util.*;

public class SetBeispiel {

    static void werteEinfuegen(Set<String> namen) {
        namen.add("Alice");
        namen.add("Bob");
        namen.add("Andrea");
        namen.add("franz");
        namen.add("Franz");
        namen.add("Susi");
        namen.add("Hannes");
        namen.add("juergen");
        namen.add("Franz");
        namen.add("Kathi");
        namen.add("Andrea");
    }

    static void werteAusgeben(Set<String> namen) {
        System.out.println("Anzahl der Element: " + namen.size());

        System.out.println("*** Ausgabe - per for-each");
        for (String name : namen) {
            System.out.println("Name: " + name);
        }

        System.out.println("*** Ausgabe - per iterator mit while schleife");
        Iterator<String> it = namen.iterator();
        while (it.hasNext()) {
            // bei jedem it.next() aufruf wird eins weiter gesprungen und das element returniert
            // it.next() sollte pro schleifendurchgang daher nur 1x aufgerufen werden.
            String name = it.next();
            System.out.println(name);
            //System.out.println(name.length() > 0 ? Character.toUpperCase(name.charAt(0)) + name.substring(1) : "");
        }
    }

    static void demoBedingungsoperator() {

        int a = 8;
        int b = 15;

        int c;

        if (a > b) {
            c = a;
        }
        else {
            c = b;
        }

        // Bedingungsoperator
        // operator ?:  <Bedingung> ? <Ausdruck-wenn-true> : <Ausdruck-wenn-false>
        c = (a > b) ? a : b;
    }

    public static void main(String[] args) {

        // TreeSet verwendet beim Vergleich standardmaessig das Comparable Interface
        // vom Elementtyp (hier String)
        //Set<String> namen = new TreeSet<>();

        // TreeSet kann auch mit einem eigenen Comparator verwendet werden.
        // Dann wird NICHT das Comparable Interface verwendet.
        //Set<String> namen = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

        Set<String> namen = new HashSet<>();

        werteEinfuegen(namen);
        werteAusgeben(namen);

        if (namen.contains("Alice")) {
            System.out.println("Ist vorhanden");
        }

        Iterator<String> it = namen.iterator();
        while (it.hasNext()) {
            // bei jedem it.next() aufruf wird eins weiter gesprungen und das element returniert
            // it.next() sollte pro schleifendurchgang daher nur 1x aufgerufen werden.
            String name = it.next();
            System.out.println(name);
            // mit remove kann ich das aktuelle element entfernen
            it.remove();
        }
    }
}
