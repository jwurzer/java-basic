package at.tectrain;

public class PersonalNr implements Comparable<PersonalNr> {

    private int abteilung;
    private int nummer;

    public PersonalNr(int abteilung, int nummer) {
        this.abteilung = abteilung;
        this.nummer = nummer;
    }

    public int getAbteilung() {
        return abteilung;
    }

    public int getNummer() {
        return nummer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PersonalNr that = (PersonalNr) o;

        if (abteilung != that.abteilung) return false;
        return nummer == that.nummer;
    }

    @Override
    public int hashCode() {
        int result = abteilung;
        result = 31 * result + nummer;
        return result;
    }

    /**
     * Wenn hashCode() bei zwei objekten aufgerufen wird, mit selben Inhalt,
     * dann muss IMMER der selbe hash-wert erzeugt werden.
     * Bei unterschiedlichen Inhalt sollte (aber muss nicht) ein unterschiedlicher
     * hash-wert erzeugt werden.
     * @return
     */
//    @Override
//    public int hashCode() {
//        return abteilung + nummer;
//    }
//
//    @Override
//    public boolean equals(Object other) {
//        if (this == other) {
//            return true;
//        }
//        // --> nicht ein und das selbe objekt
//        // --> checken ob es eine PersonalNr ist
//        if (other instanceof PersonalNr otherNr) {
//            // --> inhalt vergleichen
//            if (this.abteilung != otherNr.abteilung) {
//                return false;
//            }
//            if (this.nummer != otherNr.nummer) {
//                return false;
//            }
//            // --> abteilung und nummer sind gleich
//            return true;
//        }
//        // --> nicht gleich
//        return false;
//    }



    @Override
    public String toString() {
        return "PersonalNr{" +
                "abteilung=" + abteilung +
                ", nummer=" + nummer +
                '}';
    }

    /**
     *
     * @param other the object to be compared.
     * @return <0 wenn this kleiner als other
     *         0 wenn this gleich als other
     *         >0 wenn this groesser als other
     */
    @Override
    public int compareTo(PersonalNr other) {
        // wenn ich mehrere attribute habe, dann muss ich
        // eine prioritaet festlegen.
        // z.B.
        // 1. Attribut Abteilung, falls Abteilung gleich ist dann
        // 2. Attribut Nummer
        if (this.abteilung > other.abteilung) {
            return 1;
        }
        if (this.abteilung < other.abteilung) {
            return -1;
        }
        // --> abteilung ist gleich --> nummer wird nun verglichen
        if (this.nummer > other.nummer) {
            return 1;
        }
        if (this.nummer < other.nummer) {
            return -1;
        }
        // --> auch nummer ist gleich --> objekte sind gleich
        // falls ich noch ein Attribut habe, dann naechsten behandeln.
        return 0;
    }
}
