package at.tectrain;

public class BankDemo {

    public static void main(String[] args) {
        Bankkonto konto = new Bankkonto("Alice", 5000);
        System.out.println(konto);

        konto.abheben(100);
        System.out.println(konto);
    }
}
