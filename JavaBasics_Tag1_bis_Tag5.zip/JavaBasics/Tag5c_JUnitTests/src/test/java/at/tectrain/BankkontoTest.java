package at.tectrain;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class BankkontoTest {

    @BeforeAll
    static void setupBankkontoTest() {
        System.out.println("Bevor die Klasse erstellt wird");
    }

    @AfterAll
    static void zumSchluss() {
        System.out.println("Die Tests sind vorbei");
    }

    @BeforeEach
    void setup(TestInfo info) {
        System.out.println("Setup: " + info.getDisplayName() + ", " + info.getTestMethod());
    }

    @AfterEach
    void nachDemTest(TestInfo info) {
        System.out.println("danach: " + info.getDisplayName() + ", " + info.getTestMethod());
    }

    @ParameterizedTest
    @ValueSource(doubles = {100.0, 200.1, 123.0})
    void testBankkontoErstellen(double initKontostand) {
        Bankkonto konto = new Bankkonto("Bob", initKontostand);

        // ueberprueft den Namen
        assertEquals("Bob", konto.getBesitzer());
        // ueberprueft den kontostand
        assertEquals(initKontostand, konto.getKontostand(), 0.000001);
        // ueberprueft die kontonummer
        assertEquals(Bankkonto.getNextKontoNr() - 1, konto.getKontoNr());
    }

    @Nested
    @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
    class FailBankkontoTest {

        @Test
        @DisplayName("Test fuer negatives Einzahlen")
        @Order(2)
        void testFailEinzahlen() {
            Bankkonto konto = new Bankkonto("Alice", 1000);

            // fuer die lambda expression aus und erwartet sich dabei die IllegalArgumentException
            assertThrowsExactly(IllegalArgumentException.class, () -> konto.einzahlen(-10));
        }

        @Test
        @DisplayName("Test fuer negatives Abheben")
        @Order(1)
        void testFailAbheben() {
            Bankkonto konto = new Bankkonto("Alice", 1000);

            // fuer die lambda expression aus und erwartet sich dabei die IllegalArgumentException
            assertThrowsExactly(IllegalArgumentException.class, () -> konto.abheben(-10));
        }
    }

    @Test
    void testBankkontenName() {
        Bankkonto konto = new Bankkonto("Alice", 1000);
        assertNotNull(konto);

        if (!konto.getBesitzer().equals("Alice")) {
            fail();
        }
    }
}
