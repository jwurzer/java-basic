package at.tectrain;

import java.util.Objects;

public class StringBeispiel {
    public static void main(String[] args) {

        String s1 = "hallo";
        //String s2 = new String("test"); // new String ist nicht notwendig
        String s2 = "test";
        String s3 = new String("hallo"); // hier wird ein neues string objekt erzwungen
        //String s3 = "hallo";
        String s4 = s1;

        String s5 = s1;

        // Wenn ich probiere eine String zu aendern, wird immer ein neues Objekt im Hintergrund angelegt.
        s5 += " asdf";
        s5 += " ABC";
        s5 += " xyz";
        // es gibt keine Möglichkeit ein String Objekt zu veraendern.
        //s5.charAt(3) = 'A'; // das funktioniert natuerlich nicht
        System.out.println(s5);

        // Achtung: hier werden nur die Referenzen miteinander verglichen!
        if (s1 == s3) {
            System.out.println("s1 == s3: String ist ein und das selbe Object");
        }
        if (s1 == s4) {
            System.out.println("s1 == s4: String ist ein und das selbe Object");
        }

        // so sollte immer ein string verglichen werden
        // HIER WIRD DER INHALT VERGLICHEN
        if (s1.equals(s3)) {
            System.out.println("inhalt von s1 und s3 sind gleich");
        }

        // Bei dieser Variante wird auch der Inhalt verglichen. Zusaetzlich darf s1 und/oder s3 null sein.
        if (Objects.equals(s1, s3)) {
            System.out.println("");
        }
    }
}
