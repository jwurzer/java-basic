package at.tectrain;

import java.util.*;
import java.util.stream.Stream;

public class LambdaStreamApiBsp {

    static void printString(String s) {
        System.out.println("***** " + s);
    }

    public static void main(String[] args) {

        List<String> namen = new ArrayList<>();

        namen.add("Alice");
        namen.add("Bob");
        namen.add("Andrea");
        namen.add("Susi");
        namen.add("Hannes");
        namen.add("Franz");
        namen.add("Roman");
        namen.add("Adrian");
        namen.add("Kathi");

        System.out.println("================== AUSGABE ====================");
        namen.forEach((String str) -> {
            System.out.println("+++ " + str + " +++");
        });

        System.out.println("================== AUSGABE ====================");
        namen.forEach((String str) -> { System.out.println("+++ " + str + " +++"); });

        System.out.println("================== AUSGABE ====================");
        namen.forEach(str -> System.out.println("+++ " + str + " +++"));

        System.out.println("================== AUSGABE ====================");
        namen.forEach(str -> System.out.println(str));

        System.out.println("================== AUSGABE ====================");
        // referenz auf eine instanz methode
        namen.forEach(System.out::println);

        System.out.println("================== AUSGABE ====================");
        // referenz auf eine statische methode
        namen.forEach(LambdaStreamApiBsp::printString);

        System.out.println("================== Von allen Elementen length() aufrufen ====================");
        // referenz auf eine instanz methode wo das element fuer den aufruf verwendet wird
        // ist so jetzt sinnfrei, weil keine ausgabe
        namen.forEach(String::length);

        // referenz auf einen konstruktor
        // wird wird fuer jedes string-element eine kopie angelegt und gleich wieder verworfen
        // is so jetzt sinnfrei
        namen.forEach(String::new);

        System.out.println("================== sortierte AUSGABE ====================");
        // implementierung eines comparators per lambda expression
        // sortiert nach laenge
        namen.sort((s1, s2) -> s1.length() - s2.length());
        namen.forEach(System.out::println);

        System.out.println("================== sortierte AUSGABE ====================");
        // implementierung eines comparators per lambda expression
        // sortiert nach laenge und wenn gleich dann alphabetisch
        namen.sort((s1, s2) -> (s1.length() - s2.length() != 0) ? (s1.length() - s2.length()) : s1.compareTo(s2));
        namen.forEach(System.out::println);

        // loeschen aller namen mit der laenge 5
        //namen.removeIf(str -> str.length() == 5);
        //System.out.println("================== AUSGABE ====================");
        //namen.forEach(LambdaStreamApiBsp::printString);

        System.out.println("============== Namen mit A ================");
        // gibt alle namen beginnend mit A aus
        Stream<String> stream = namen.stream();
        stream.filter(s -> s.startsWith("A")).forEach(System.out::println);

        System.out.println("================== AUSGABE ====================");
        namen.forEach(LambdaStreamApiBsp::printString);

        // es koennen mehrere filter verwendet werden
        namen.stream()
                .filter(s -> s.length() >= 4)
                .filter(s -> s.length() < 10)
                .forEach(System.out::println);

        // selbes bsp mit einem filter
        namen.stream()
                .filter(s -> s.length() >= 4 && s.length() < 10)
                .forEach(System.out::println);

        System.out.println("==== alle namen die ein a im namen haben und anschliessend in blockschrift als array ===");
        // ergebnis speichern in einem array
        // alle namen die ein a im namen haben und anschliessend in blockschrift als array
        List<String> ergebnis = namen.stream()
                .filter(name -> name.toLowerCase().contains("a")) // alle namen die ein a enthalten
                //.map(name -> name.toUpperCase()) // name wird auf blockschrift gemappt.
                .map(String::toUpperCase) // name wird auf blockschrift gemappt. (variante per methodenreferenz)
                .toList();
        ergebnis.forEach(System.out::println);

        System.out.println("==== Beispiel as Array ===");
        // ergebnis speichern in einem array
        // alle namen die ein a im namen haben und anschliessend in blockschrift als array
        String [] erg2 = namen.stream()
                .filter(name -> name.toLowerCase().contains("a")) // alle namen die ein a enthalten
                //.map(name -> name.toUpperCase()) // name wird auf blockschrift gemappt.
                .map(String::toUpperCase) // name wird auf blockschrift gemappt. (variante per methodenreferenz)
                //.toArray(nr -> new String[nr]);
                .toArray(String[]::new); // referenz auf den array-constructor

        // mit der hilfsklasse Arrays kann ich mir fuer ein array einen stream erstellen
        Arrays.stream(erg2).forEach(System.out::println);

        System.out.println("*** suche den laengsten namen ***");
        //namen.clear(); // loesch alle eintraege, zum testen
        Optional<String> maxName = namen.stream()
                .max((s1, s2) -> (s1.length() - s2.length() != 0) ? (s1.length() - s2.length()) : s1.compareTo(s2));
        if (maxName.isPresent()) {
            String name = maxName.get();
            System.out.println("max name wurde gefunden und ist: " + name);
        }
        else {
            System.out.println("kein name wurde gefunden");
        }

        // wird nur ausgegeben, falls vorhanden
        maxName.ifPresent(s -> System.out.println("Gefunden: Name ist " + s));

        String erg3 = maxName.orElse("Keinen Namen gefunden");
        System.out.println(erg3);

    }
}
