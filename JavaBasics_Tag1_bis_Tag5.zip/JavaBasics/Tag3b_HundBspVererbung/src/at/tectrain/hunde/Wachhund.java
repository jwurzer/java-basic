package at.tectrain.hunde;

public class Wachhund extends Hund {

    // standort wo der Wachhund aufpasst
    private String standort;

    public Wachhund() {
        // super() ruft den Konstruktor der Basisklasse Hund auf.
        // Wenn super() nicht explizit aufgerufen wird,
        // dann wird es implizit (trotzdem automatisch) aufgerufen.
        super();
        standort = "tecTrain";
    }

    // mit super() und anschliessend setName() und setChipId()
    // ist es nicht performant.
    public Wachhund(String name, int chipId, String standort) {
        super(name, chipId);
        this.standort = standort;
    }

    public String getStandort() {
        return standort;
    }

    public void setStandort(String standort) {
        this.standort = standort;
    }

    @Override
    public void zeigeTrick() {
        System.out.println("(schleicht sich an)");
        // hier wird die implementierung der Basisklasse Hund aufgerufen.
        super.zeigeTrick();
        System.out.println("(attackiert)");
        super.zeigeTrick();
    }

    @Override
    public String toString() {
        // super.toString() ruft die implementierung vom Hund auf.
        return super.toString() + ", standort: " + standort;
    }
}
