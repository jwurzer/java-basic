package at.tectrain.geometrie;

import at.tectrain.FatalArgumentException;

public class Kreis implements Geometrie {
    private double radius;

    public Kreis(double radius) throws FatalArgumentException { // throws FatalArgumentException ist noetig bei einer checked exception
        if (radius <= 0.0) {
            // mit throw werfe ich die exception
            //FatalArgumentException e = new FatalArgumentException();
            //throw e;
            throw new FatalArgumentException("Radius ist neg. oder 0. radius: " + radius);
        }
        this.radius = radius;
    }

    public void setRadius(double radius) throws FatalArgumentException {
        if (radius <= 0.0) {
            throw new FatalArgumentException("Radius ist neg. oder 0. radius: " + radius);
        }
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public double umfang() {
        return (radius + radius) * Math.PI;
    }

    @Override
    public double flaeche() {
        return radius * radius * Math.PI;
    }

    @Override
    public String toString() {
        return "Kreis{" +
                "radius=" + radius +
                '}';
    }
}
