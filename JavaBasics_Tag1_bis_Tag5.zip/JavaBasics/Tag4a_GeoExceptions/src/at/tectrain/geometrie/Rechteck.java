package at.tectrain.geometrie;

public class Rechteck implements Geometrie {
    private double laenge;
    private double breite;

    public Rechteck(double laenge, double breite) {
        if (laenge <= 0.0) {
            throw new IllegalArgumentException("Laenge " + laenge + " ist nicht erlaubt");
        }
        if (breite <= 0.0) {
            throw new IllegalArgumentException("Breite " + breite + " ist nicht erlaubt");
        }
        this.laenge = laenge;
        this.breite = breite;
    }

    public double getLaenge() {
        return laenge;
    }

    public double getBreite() {
        return breite;
    }

    @Override
    public double umfang() {
        return (laenge + breite) * 2.0;
    }

    @Override
    public double flaeche() {
        return laenge * breite;
    }

    @Override
    public String toString() {
        return "Rechteck{" +
                "laenge=" + laenge +
                ", breite=" + breite +
                '}';
    }
}
