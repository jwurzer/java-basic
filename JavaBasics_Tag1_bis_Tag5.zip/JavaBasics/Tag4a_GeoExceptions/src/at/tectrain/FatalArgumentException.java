package at.tectrain;


// extends Exception --> checked exception
// extends RuntimeException --> unchecked exception
public class FatalArgumentException extends Exception {

    public FatalArgumentException() {
        super();
    }

    public FatalArgumentException(String msg) {
        super(msg);
    }

    public FatalArgumentException(String msg, Throwable throwable) {
        super(msg, throwable);
    }
}
