package at.tectrain;

import at.tectrain.geometrie.Geometrie;
import at.tectrain.geometrie.Kreis;
import at.tectrain.geometrie.Rechteck;

import java.util.Scanner;

public class GeoBeispiel {

    public static void main(String[] args) {

        Scanner eingabe = new Scanner(System.in);

        try {
            double laenge = EingabeHelper.doubleEinlesen(eingabe, "laenge");
            double breite = EingabeHelper.doubleEinlesen(eingabe, "breite");
            Geometrie g1 = new Rechteck(laenge, breite);
            System.out.println("umfang von g1: " + g1.umfang());
            System.out.println(g1);
        }
        catch (IllegalArgumentException e) {
            System.out.println("Rechteck konnte nicht angelegt werden. Msg: " + e.getMessage());
        }

        try {
            double radius = EingabeHelper.doubleEinlesen(eingabe, "radius");
            Geometrie g2 = new Kreis(radius);
            System.out.println("umfang von g2: " + g2.umfang());
            System.out.println(g2);
        }
        catch (FatalArgumentException e) {
            System.out.println("Kreis konnte nicht angelegt werden. Msg: " + e.getMessage());
        }
    }
}
