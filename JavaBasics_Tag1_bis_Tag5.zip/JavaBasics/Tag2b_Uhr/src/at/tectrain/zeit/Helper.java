package at.tectrain.zeit;

public class Helper {

    // eine Hilfsmethode die von einem Objekt Uhr die Zeit auf 0:00 stellt.
    public static void resetUhrzeit(Uhr uhr) {
        uhr.uhrzeitEinstellen(0, 0);
    }

    // hat nicht den gewuenschten effekt.
    public static void resetUhrzeitV2(Uhr uhr) {
        uhr = new Uhr(0, 0);
    }

    // die wurde funktionierten
    public static Uhr resetUhrzeitV3() {
        return new Uhr(0, 0);
    }
}
