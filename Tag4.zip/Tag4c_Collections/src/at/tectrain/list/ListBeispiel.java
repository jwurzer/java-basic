package at.tectrain.list;

import java.util.*;

public class ListBeispiel {

    public static void main(String[] args) {

        //List<String> namen = new ArrayList<>();
        List<String> namen = new LinkedList<>();

        namen.add("Alice");
        namen.add("Bob");
        namen.add("Andrea");
        namen.add("Franz");
        namen.add("Susi");
        namen.add("Hannes");
        namen.add("Kathi");

        // .get() zugriff auf ein einzelnes element.
        String element = namen.get(3);
        System.out.println(element);

        namen.remove(5);

        System.out.println(namen.get(2));

        System.out.println("*** Ausgabe - per for mithilfe von get() ***");
        for (int i = 0; i < namen.size(); ++i) {
            // zugriff per get() ist bei der ArrayList schnell.
            // hingegen bei der LinkedList muss bis zu diesem Element durchlaufen werden.
            System.out.println(i + ": " + namen.get(i));
        }

        System.out.println("*** Ausgabe - per for-each");
        // wird im hintergrund der iterator verwendet
        // --> alle klassen die Iterable<T> interface impl koennen in einer for-each verwendet werden.
        for (String n : namen) {
            System.out.println("Name: " + n);
        }

        System.out.println("*** Ausgabe - per iterator mit while schleife");
        Iterator<String> it = namen.iterator();
        while (it.hasNext()) {
            // bei jedem it.next() aufruf wird eins weiter gesprungen und das element returniert
            // it.next() sollte pro schleifendurchgang daher nur 1x aufgerufen werden.
            String name = it.next();
            System.out.println(name);
        }

//        for (Iterator<String> it2 = namen.iterator(); it2.hasNext(); ) {
//            String name = it2.next();
//            System.out.println(name);
//        }
    }
}
