package at.tectrain.uhr;

@FunctionalInterface
public interface UhrenFilter {

    /**
     * Die Methode kann etwas beliebiges ueberpruefen.
     * @param uhr
     * @return True wenn es zu trift. Ansonst false.
     */
    public boolean isTrueFor(Uhr uhr);
}
