package at.tectrain;

import at.tectrain.uhr.Uhr;
import at.tectrain.uhr.UhrenFilter;

public class IstNach12Uhr implements UhrenFilter {

    /**
     *
     * @param uhr
     * @return
     */
    @Override
    public boolean isTrueFor(Uhr uhr) {
        if (uhr.getStunde() > 12) {
            return true;
        }
        if (uhr.getStunde() == 12 && uhr.getMinute() > 0) {
            return true;
        }
        return false;
    }
}
