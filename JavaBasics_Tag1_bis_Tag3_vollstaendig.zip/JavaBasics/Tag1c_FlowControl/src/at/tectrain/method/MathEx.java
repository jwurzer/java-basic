package at.tectrain.method;

public class MathEx {

    static float sum(float [] nums) {
        float s = 0;
        for (float nr : nums) {
            s += nr;
        }
        return s;
    }
}
