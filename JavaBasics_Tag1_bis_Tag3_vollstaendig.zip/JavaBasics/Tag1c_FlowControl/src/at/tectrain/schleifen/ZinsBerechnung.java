package at.tectrain.schleifen;

import java.util.Scanner;

public class ZinsBerechnung {
    public static void main(String[] args) {
        // Eingabe fuer Startwert (Startbetrag)
        // Eingabe fuer Zinsen in Prozent
        // Eingabe fuer Anzahl der Jahre
        // Ausgabe des Gesamtbetrags.

        Scanner eingabe = new Scanner(System.in);

        double betrag, zinsen;
        int jahre;

        System.out.print("Bitte Startkapital eingeben: ");
        betrag = eingabe.nextDouble();
        System.out.print("Bitte Zinsen eingeben: (in Prozent, z.b. 2,5 fuer 2,5 Prozent) ");
        zinsen = eingabe.nextDouble();
        System.out.print("Bitte Anzahl der Jahre eingeben: ");
        jahre = eingabe.nextInt();

        for (int i = 0; i < jahre; ++i) {
            double faktor = 1.0 + zinsen / 100.0;
            //betrag = betrag * faktor; // laengere schreibweise
            betrag *= faktor; // kurze schreibweise

            System.out.println("Betrag nach " + (i + 1) + " Jahre(n): " + betrag);
        }

        System.out.println("Betrag: " + betrag);
    }
}
