package at.tectrain.schleifen;

import java.util.Scanner;

public class Schleifen {
    public static void main(String[] args) {

        // eingabe fuer ein monat zwischen 1 und 12
        // bei einer falschen eingabe soll die eingabe wiederholt werden.
        // nach der richtigen soll zum schluss das monat ausgegeben werden.

        Scanner eingabe = new Scanner(System.in);

        byte monat;

        // 1. Loesung mit "endlosschleife" + break.
        while (true) {

            System.out.print("Bitte Monat als Zahl eingeben (1-12): ");

            monat = eingabe.nextByte();
            if (monat >= 1 && monat <= 12) {
                // break sprint aus schleifen (und aus einem switch anweisung)
                break;
            }

            System.out.println("Es wurde eine falsche Eingabe getaetigt!");
        }

        System.out.println("Monat " + monat + " wurde ausgewaehlt");


        // 2. Loesung: mit do-while schleife, die wird immer mindestens 1x durchlaufen
        do {
            System.out.print("Bitte Monat als Zahl eingeben (1-12): ");

            monat = eingabe.nextByte();

            if (monat < 1 || monat > 12) {
                System.out.println("Es wurde eine falsche Eingabe getaetigt!");
            }
        //} while (!(monat >= 1 && monat <= 12)); // etwas kompliziert
        } while (monat < 1 || monat > 12); // wenn erfuellt --> keine gueltige eingabe --> eingabe muss wiederholt werden

        // 3. Loesung: mit eine while-schleife
        monat = 0;
        while (monat < 1 || monat > 12) {
            System.out.print("Bitte Monat als Zahl eingeben (1-12): ");

            monat = eingabe.nextByte();

            if (monat < 1 || monat > 12) {
                System.out.println("Es wurde eine falsche Eingabe getaetigt!");
            }
        }

        // 4. Loesung: mit eine while-schleife
        System.out.print("Bitte Monat als Zahl eingeben (1-12): ");
        monat = eingabe.nextByte();
        while (monat < 1 || monat > 12) {
            System.out.println("Es wurde eine falsche Eingabe getaetigt!");
            System.out.print("Bitte Monat als Zahl eingeben (1-12): ");
            monat = eingabe.nextByte();
        }

        // waere eine endlosschleife
        //for (;;) {
        //}

        // eine for-schleife fuer dieses bsp eher unueblich
        for (monat = 0; monat < 1 || monat > 12; monat = eingabe.nextByte()) {
            System.out.print("Bitte Monat als Zahl eingeben (1-12): ");
        }

        // for-schleife wird normalerweise fuers "durchlaufen" verwenden

    }
}
