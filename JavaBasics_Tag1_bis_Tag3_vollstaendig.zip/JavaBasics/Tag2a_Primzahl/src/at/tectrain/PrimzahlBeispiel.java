package at.tectrain;

import at.tectrain.helper.Helper;

import java.util.Scanner;

public class PrimzahlBeispiel {
    public static void main(String[] args) {
        // zwei zahlen einlesen fuer start und end wert
        // alle zahlen dazwischen (inkl.) auf primzahl ueberprufen
        // nur die primzahlen ausgeben

        Scanner eingabe = new Scanner(System.in);
        System.out.println("Bitte Start- und Endwert angeben.");
        long start = eingabe.nextLong();
        long ende = eingabe.nextLong();
        for (long nr = start; nr <= ende; ++nr) {
            if (Helper.isPrimzahl(nr)) {
                System.out.print(" " + nr);
            }
        }
    }
}
