package at.tectrain;

import at.tectrain.hunde.Hund;
import at.tectrain.hunde.Wachhund;

public class HundeBsp {

    public static void main(String[] args) {
        Hund rex = new Hund("Rex", 7);
        Wachhund w1 = new Wachhund();
        Wachhund w2 = new Wachhund("Maxi", 10, "ITSV");

        // referenz vom Typ Object auf ein Objekt vom Typ Wachhund ist erlaubt,
        // da auch der Wachhund indirekt ueber den Hund von der Klasse Object erbt.
        Object obj = w2;
        System.out.println(obj.toString());

        // --> Referenz vom Typ Hund zeigt auf ein Objekt vom Typ Wachhund
        // hier erfolgt auch ein impliziter Cast von Wachhund auf Hund (upcast)
        Hund h1 = w1;
        //Hund h1 = rex;
        // was passiert nun wenn ich h1 zum Aufruf von zeigeTrick() verwende?
        // * Implementierung von Hund.zeigeTrick()?
        // * Implementierung von Wachhund.zeigeTrick()?
        h1.zeigeTrick();

        // Aufruf von getStandort() per w1 ref
        System.out.println(w1.getStandort());
        // Aufruf von getStandort() per h1 ref nicht moeglich, da h1 ein Hund ist.
        //System.out.println(h1.getStandort());
        // von Hund zu Wachhund ist ein expliziter cast notwendig. (downcast)
        // Sollte nur durchgefuehrt werden, wenn zuvor auf den Typ ueberprueft wird.
        //Wachhund tmp = (Wachhund) h1; // ohne ueberpruefung sollte der cast so nicht durchgefuehrt werden.
        //System.out.println(tmp.getStandort());
        System.out.println(((Wachhund)h1).getStandort()); // ohne ueberpruefung sollte der cast so nicht durchgefuehrt werden.

        if (h1 instanceof Wachhund) {
            // --> es ist mindestens ein Wachhund
            // --> downcast auf Wachhund problemlos moeglich
            Wachhund tmp1 = (Wachhund)h1;
            System.out.println(tmp1.getStandort());
        }
        // ab version 16 auch so moeglich
        if (h1 instanceof Wachhund tmp1) {
            System.out.println(tmp1.getStandort());
        }

        if (h1.getClass() == Wachhund.class) {
            // --> es ist exact ein Wachhund
            Wachhund tmp1 = (Wachhund)h1;
            System.out.println(tmp1.getStandort());
        }


        String demo = "xyz";
        int len = demo.length();

        String n = rex.getName();
        n.length();
        // auch in einem schritt moeglich
        rex.getName().length();

        rex.zeigeTrick();

        w1.zeigeTrick();
        w2.zeigeTrick();

        System.out.println(rex);
        // gleich wie
        //System.out.println(rex.toString());
        System.out.println(w1);
        System.out.println(w2);
    }
}
