package at.tectrain;

public class StringBuilderBsp {

    public static void main(String[] args) {

        String s = "";
        for (int i = 0; i < 10; ++i) {
            s += " " + i;
        }
        System.out.println(s);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; ++i) {
            sb.append(' ');
            sb.append(i);
        }
        String s2 = sb.toString();
        System.out.println(s2);
    }
}
