package at.tectrain;

import at.tectrain.zeit.Helper;
import at.tectrain.zeit.Uhr;

public class UhrenBeispiel {

    public static void main(String[] args) {

        long x = 3;
        Uhr zeit1 = new Uhr(10, 20);
        Uhr zeit2 = new Uhr();

        Uhr zeit3;

        zeit3 = null;
        //zeit3.ausgabe();

        zeit3 = new Uhr(zeit1);

        Uhr zeit4 = zeit2;

        zeit1.ausgabe();
        zeit2.ausgabe();

        zeit1.uhrzeitEinstellen(13, 10);

        zeit2.uhrzeitEinstellen(9, 5);

        zeit4.setMinute(55);

        //Helper.resetUhrzeit(zeit1);
        //Helper.resetUhrzeitV2(zeit1);
        zeit1 = Helper.resetUhrzeitV3();

        //Helper.resetUhrzeit(zeit4);
        zeit4 = Helper.resetUhrzeitV3();

        zeit1.ausgabe();
        zeit2.ausgabe();
        zeit3.ausgabe();
    }
}
