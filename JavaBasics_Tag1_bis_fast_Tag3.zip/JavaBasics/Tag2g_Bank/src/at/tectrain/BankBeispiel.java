package at.tectrain;

import at.tectrain.bank.Bankkonto;
import at.tectrain.bank.Verwaltung;

public class BankBeispiel {
    public static void main(String[] args) {
        //Bankkonto konto = new Bankkonto(7, "Alice", 123.4);
        //konto.ausgabe();
        //System.out.println(konto.toString());

        Verwaltung bankVerwaltung = new Verwaltung(10);

        Bankkonto konto1 = new Bankkonto(7, "Alice", 123.4);
        bankVerwaltung.kontoHinzufuegen(konto1);

        Bankkonto konto2 = new Bankkonto(10, "Bob", 23.4);
        bankVerwaltung.kontoHinzufuegen(konto2);

        System.out.println(bankVerwaltung.toString());
        bankVerwaltung.ueberweisen(7, 10, 50.0);
        // ruft automatisch .toString() auf, wenn es nicht dazugeschrieben wird.
        System.out.println(bankVerwaltung);
    }
}
