package at.tectrain.hunde;

public interface Hund {

    void zeigeTrick();

    String getName();
    int getChipId();
}
