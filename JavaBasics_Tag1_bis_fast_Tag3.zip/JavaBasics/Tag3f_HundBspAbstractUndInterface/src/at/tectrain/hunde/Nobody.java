package at.tectrain.hunde;

public class Nobody implements Hund {
    @Override
    public void zeigeTrick() {
        System.out.println("(schlafe)");
    }

    @Override
    public String getName() {
        return "Nobody";
    }

    @Override
    public int getChipId() {
        return -1;
    }
}
