package at.tectrain.hunde;

public class Blindenhund extends AbstractHund {
    private String blindePerson;

    public Blindenhund(String name, int chipId, String blindePerson) {
        super(name, chipId);
        this.blindePerson = blindePerson;
    }

    public String getBlindePerson() {
        return blindePerson;
    }

    public void setBlindePerson(String blindePerson) {
        this.blindePerson = blindePerson;
    }

    @Override
    public void zeigeTrick() {
        System.out.println("begleite blinde person " + blindePerson);
    }

    @Override
    public String toString() {
        return super.toString() + ", blindePerson: " + blindePerson;
    }
}
