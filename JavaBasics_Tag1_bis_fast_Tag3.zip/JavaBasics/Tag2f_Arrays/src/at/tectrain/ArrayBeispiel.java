package at.tectrain;

import java.util.Arrays;

public class ArrayBeispiel {

    public static void main(String[] args) {

        //float [] nums = new float[] {9.3f, 2.3f, 4, 5.3f, 7, 8};
        float [] nums = {9.3f, 2.3f, 4, 5.3f, 7, 8};

        System.out.println("nums: " + nums.toString());

        System.out.println("nums: " + Arrays.toString(nums));
        Arrays.sort(nums);
        System.out.println("nums: " + Arrays.toString(nums));
    }
}
