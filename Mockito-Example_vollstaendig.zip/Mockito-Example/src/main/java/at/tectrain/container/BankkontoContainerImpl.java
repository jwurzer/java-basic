package at.tectrain.container;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import at.tectrain.model.BankException;
import at.tectrain.model.Bankkonto;

public class BankkontoContainerImpl implements BankkontoContainer {

	private List<Bankkonto> konten = new ArrayList<>();
	
	@Override
	public List<Bankkonto> alleBankkonten() {
		return List.copyOf(konten);
	}

	/**
	 * Retourniert das erste gefundene Bankkonto mit der angegebenen id.
	 * @param kontoId
	 * @return Gefundenes Bankkonto
	 * @throws BankException Fuer nicht gefunden oder anderen internen Fehler
	 */
	@Override
	public Bankkonto suche(int kontoNr) throws BankException {
		Optional<Bankkonto> konto = find(kontoNr);
		// if not found: throw BankException
		return konto.orElseThrow(() -> new BankException("Konto mit Nr " + kontoNr +  " existiert nicht"));
	}
	
	/**
	 * Fuegt eine neue Karte hinzu.
	 * @param konto
	 * @return Liefert true bei Erfolg.
	 *         False falls es schon eine Karte mit dieser Id gibt.
	 * @throws BankException Fuer anderen internen Fehler (kein Platz, etc.)
	 */
	@Override
	public void hinzufuegen(Bankkonto konto) throws BankException {
		Optional<Bankkonto> gefundenesKonto = find(konto.getKontoNr());
		if (gefundenesKonto.isPresent()) {
			throw new BankException("Konto mit Nr " + konto.getKontoNr() + " existiert bereits!");
		}
		konten.add(konto);
	}

	/**
	 * Aktualisiert das Bankkonto.
	 * z.B. Update in die Datenbank, aktualisiert in die Datei etc.
	 * @param konto
	 * @throws BankException Falls das update fehl schlägt.
	 */
	@Override
	public void update(Bankkonto konto) throws BankException {
		Bankkonto orig = suche(konto.getKontoNr());
		konten.set(konten.indexOf(orig), konto);
	}
	
	/**
	 * Fuegt eine neue Karte hinzu.
	 * @param konto
	 * @return Liefert true bei erfolgreichem loeschen.
	 *         False falls es kein Konto mit dieser Id gibt.
	 * @throws BankException Fuer anderen internen Fehler
	 */
	@Override
	public void entfernen(int kontoId) throws BankException {
		Bankkonto orig = suche(kontoId);
		konten.remove(orig);
	}
	
	private Optional<Bankkonto> find(int kontoId) {
		return konten.stream().filter(k -> k.getKontoNr() == kontoId).findFirst();
	}
}
