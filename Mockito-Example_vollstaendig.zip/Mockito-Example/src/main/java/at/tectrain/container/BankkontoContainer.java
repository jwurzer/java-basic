package at.tectrain.container;

import java.util.List;

import at.tectrain.model.BankException;
import at.tectrain.model.Bankkonto;

// Schnittstelle zum Verwalten/speichern von mehreren Bankkonten
public interface BankkontoContainer {

	List<Bankkonto> alleBankkonten();

	/**
	 * Retourniert das erste gefundene Bankkonto mit der angegebenen id.
	 * @param kontoId
	 * @return Gefundenes Bankkonto
	 * @throws BankException Fuer nicht gefunden oder anderen internen Fehler
	 */
	Bankkonto suche(int kontoNr) throws BankException;
	
	/**
	 * Fuegt eine neue Karte hinzu.
	 * @param konto
	 * @throws BankException Falls es schon eine Karte mit dieser Id gibt.
	 *         Fuer anderen internen Fehler (kein Platz, etc.)
	 */
	void hinzufuegen(Bankkonto konto) throws BankException;

	/**
	 * Aktualisiert das Bankkonto.
	 * z.B. Update in die Datenbank, aktualisiert in die Datei etc.
	 * @param konto
	 * @throws BankException Falls das update fehl schlägt.
	 */
	void update(Bankkonto konto) throws BankException;
	
	/**
	 * Entfernt ein Bankkonto.
	 * @param konto
	 * @throws BankException Falls es kein Konto mit dieser Id gibt. Fuer anderen internen Fehler
	 */
	void entfernen(int kontoId) throws BankException;
}
