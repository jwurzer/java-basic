package at.tectrain.test;

import at.tectrain.container.BankkontoContainer;
import at.tectrain.container.BankkontoContainerImpl;
import at.tectrain.model.BankException;
import at.tectrain.model.Bankkonto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BankkontoContainerTest {

    BankkontoContainer konten;

    @BeforeEach
    void setup() {
        konten = new BankkontoContainerImpl();
    }

    /**
     * Ob der BankkontoContainer richtig ueberprueft ob die Kontonummer des neuen Kontos noch nicht verwendet wird.
     * bzw. die Kontonr. noch frei ist.
     */
    @Test
    void testMitZweiGleichenKontoNummern() {

        // erzeugt ein mock objekt fuer das Bankkonto
        Bankkonto mockKontoA = mock(Bankkonto.class);
        Bankkonto mockKontoKopie = mock(Bankkonto.class);

        System.out.println("kontonr " + mockKontoA.getKontoNr() + ", betrag " + mockKontoA.getKontostand());
        // festlegen was das mock objekt bei getKontoNr() zurueck liefern soll.
        //when(mockKontoA.getKontoNr()).thenReturn(17);
        when(mockKontoKopie.getKontoNr()).thenReturn(17);
        // alternative auch so moeglich
        doReturn(17).when(mockKontoA).getKontoNr();

        System.out.println("kontonr " + mockKontoA.getKontoNr() + ", betrag " + mockKontoA.getKontostand());

        konten.hinzufuegen(mockKontoA);

        // sollte nach dem hinzufuegen den wert 1 haben.
        assertEquals(1, konten.alleBankkonten().size());
        // da die mockKontoKopie dieselbe Kontonummer wie mockKontoA zurueck gibt, muss eine BankException fallen
        assertThrows(BankException.class, () -> konten.hinzufuegen(mockKontoKopie));

        // z.b. koennte man nochmal ueberpruefen ob wirklich nun nur 1 konto gespeichert wurde
        assertEquals(1, konten.alleBankkonten().size());
    }

    @Test
    void testBankkontoEntfernen(@Mock Bankkonto mockKonto) {
        when(mockKonto.getKontoNr()).thenReturn(17);

        // konto hinzufuegen
        konten.hinzufuegen(mockKonto);
        // sollte nach dem hinzufuegen den wert 1 haben.
        assertEquals(1, konten.alleBankkonten().size());

        // konto entfernen
        konten.entfernen(mockKonto.getKontoNr());
        // sollte nach dem entfernen den wert 0 haben.
        assertEquals(0, konten.alleBankkonten().size());

        // bei nochmaligen entfernen muss eine exception fliegen
        assertThrows(BankException.class, () -> konten.entfernen(mockKonto.getKontoNr()));
    }
}
