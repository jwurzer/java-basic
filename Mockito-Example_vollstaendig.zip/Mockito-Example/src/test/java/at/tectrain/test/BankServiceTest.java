package at.tectrain.test;

import at.tectrain.container.BankService;
import at.tectrain.container.BankkontoContainer;
import at.tectrain.model.BankException;
import at.tectrain.model.Bankkonto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BankServiceTest {

    @Mock
    BankkontoContainer konten;

    // bewirkt das beim Mock konten vom Typ BankkontoContainer zusaetzlich mit aufgezeichnet wird.
    // BankService verwendet automatisch den mock BankkontoContainer
    // --> kein new BankService(konten); notwendig
    @InjectMocks
    BankService service;

    /**
     * Ueberprueft ob beim Konto aufloesen auch wirklich die entfernen() Methode vom BankkontoContainer aufgerufen wurde.
     */
    @Test
    void testKontoAufloesen() {
        double initKontostand = 17.0;
        Bankkonto konto = new Bankkonto("Alice", initKontostand);
        // wenn das BankService nach dem Konto sucht soll der BankkontoContainer konten entsprechend das Konto zurueck liefern.
        when(konten.suche(konto.getKontoNr())).thenReturn(konto);

        double restBetrag = service.kontoAufloesen(konto.getKontoNr());

        // restbetrag ueberpruefen.
        assertEquals(initKontostand - 5.0, restBetrag);
        assertEquals(initKontostand - 5.0, konto.getKontostand());

        // nun folgt die ueberpruefung ob wirklich das entfernen() vom BankkontoContainer aufgerufen wurde.
        verify(konten).entfernen(konto.getKontoNr());
    }

    @Test
    void testFailKontoAufloesen() {
        double initKontostand = 4.0;
        Bankkonto konto = new Bankkonto("Alice", initKontostand);
        // wenn das BankService nach dem Konto sucht soll der BankkontoContainer konten entsprechend das Konto zurueck liefern.
        when(konten.suche(konto.getKontoNr())).thenReturn(konto);

        // hier sollte nun eine exception fliegen, da fuer das konto aufloesen 5 euro notwendig sind.
        assertThrows(BankException.class, () -> service.kontoAufloesen(konto.getKontoNr()));

        // kontostand ueberpruefen.
        assertEquals(initKontostand, konto.getKontostand());

        // nun folgt die ueberpruefung ob wirklich das entfernen() vom BankkontoContainer NIE aufgerufen wurde.
        verify(konten, never()).entfernen(anyInt());
    }

    @Test
    void testUeberweisung() {
        // spy von echten Bankkonto-Objekten --> verify ist moeglich
        Bankkonto konto1 = spy(new Bankkonto("Alice", 200));
        Bankkonto konto2 = spy(new Bankkonto("Bob", 200));

        // BankkontoContainer muss die zwei Konten bei der Suche finden
        when(konten.suche(konto1.getKontoNr())).thenReturn(konto1);
        when(konten.suche(konto2.getKontoNr())).thenReturn(konto2);

        service.ueberweisen(konto1.getKontoNr(), konto2.getKontoNr(), 50);

        verify(konto1, times(1)).abheben(50);
        verify(konto2, times(1)).einzahlen(50);
    }
}
