package at.tectrain;

import java.util.Scanner;

public class EingabeBsp {

    public static void main(String[] args) {
        // 1) zwei zahlen einlesen (int)
        // 2) differenz und summe ausrechnen
        // 3) ausgeben, ob die erste zahl, kleiner, gleich oder groesser ist

        int zahl1, zahl2;
        // importieren mit ALT+ENTER
        Scanner input = new Scanner(System.in);

        System.out.println("Bitte zwei Zahlen eingeben:");

        zahl1 = input.nextInt();
        zahl2 = input.nextInt();

        int sum = zahl1 + zahl2;
        int diff = zahl1 - zahl2;

        if (zahl1 < zahl2) {
            System.out.println("zahl1 ist kleiner");
        }
        else if (zahl1 == zahl2) {
            System.out.println("Zahlen sind gleich");
        }
        else {
            System.out.println("Zahl 2 ist groesser");
        }

        // ob zahl1 ungleich 0 ist
        if (zahl1 != 0) {
            // ist ungleich 0
        }

        // geht so in java nicht
        //if (zahl1) {
        //}
    }
}
