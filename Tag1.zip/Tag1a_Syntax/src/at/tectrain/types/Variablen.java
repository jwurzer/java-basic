package at.tectrain.types;

public class Variablen {

    public static void main(String[] args) {


        // typ name = [init-wert];
        int anzahl = 70;

        System.out.println(anzahl);

        //int dummy;
        //System.out.println(dummy);

        // L fuer long
        long grosseZahl = 6323656321L;
        // _ sind auch erlaubt aber nicht notwendig.
        long grosseZahl2 = 1_323_656_321;

        // castet von long auf einen int
        // expliziter cast - wird extra angegeben
        anzahl = (int)grosseZahl2;

        // impliziter cast (wird automatisch durchgefuehrt)
        grosseZahl = anzahl;


        // gleitkommawerte
        double temp1 = 0.3;
        float temp2 = 0.4f;

        char zeichen = 48;
        zeichen = 'w';

        System.out.println(zeichen);

        String name = "Alice";

        System.out.println("Temperatur ist " + temp1 + " Grad.");

        String info = "Info: " + temp1 + ", groesse: " + grosseZahl;

        System.out.println(info);

        boolean istKaelter = (temp1 < temp2);

        // einzeiliges kommentar

        /*
        mehrzeiliges kommentar
        und so weiter
         */

        // escape sequenzen
        String text = "\"Hallo\"";
        char z2 = '\''; // waere ein einfaches hochkomma als zeichen gespeichert

        // zeichenumbruch mit \n
        String mehrzeilig = "Das\nist\nein Test";

        // typinferenz: typ fuer nr von "var" wird von init-wert abgeleitet.
        var nr = 5; // --> ist ein int
        var nr2 = grosseZahl2; // --> ist ein long
        var nr3 = grosseZahl == grosseZahl2; // --> waere ein boolean


        // konstante
        final int ANZAHL = 77;
        //ANZAHL = 3; darf nicht geaendert

    }
}
