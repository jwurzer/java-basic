package at.tectrain.types;

public class OperatorenBsp {

    public static void main(String[] args) {


        int zahl1 = 7;
        int zahl2 = 8;

        int result;

        result = zahl1 + zahl2;

        // erhoeht um 1
        result = result + 1;

        // erhoeht genauso um 1
        result += 1;

        int a, b;
        // erhoehgt um eins
        a = ++result;

        // erhoehgt um eins
        b = result++;

        double temp1 = -5.0;
        double minTemp = -10.0;
        double maxTemp = 20.0;

        boolean liegtDazwischen = minTemp < temp1 && temp1 < maxTemp;
        //boolean liegtDazwischen = temp1 > minTemp && temp1 < maxTemp;

        int aa = 4;
        aa <<= 1;
        System.out.println(aa);

        int x = aa + b - a;
    }

}
