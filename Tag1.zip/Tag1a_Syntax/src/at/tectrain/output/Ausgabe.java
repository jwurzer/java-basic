package at.tectrain.output;

import java.util.Locale;
import java.util.Scanner;

public class Ausgabe {

    public static void main(String[] args) {

        int stunde = 11;
        int minute = 7;

        System.out.println(stunde + ":" + minute);

        // formatierte ausgabe
        System.out.printf("Uhrzeit ist %02d:%02d\n", stunde, minute);
        // bei der formatierten ausgabe kann ich auch %n statt \n als zeilenumbruch verwenden.
        System.out.printf("Uhrzeit in hex %02x:%02x%n", stunde, minute);

        // formatierten
        String uhrzeit = String.format("%02d:%02d", stunde, minute);

        System.out.println(uhrzeit);

        double temp = 13.52364677824;

        System.out.printf("temperatur ist %+6.2f genau: %1$.10f\n", temp);

        System.out.printf(Locale.ENGLISH, "temperatur ist %.2f\n", temp);

        //System.err.println("Das ist eine Fehlermeldung!");

        // Beispiel fuer eine Eingabe
        Scanner eingabe = new Scanner(System.in);

        System.out.print("Groesse eingaben: ");
        int groesse = 0;

        if (eingabe.hasNextInt()) {
            groesse = eingabe.nextInt();
            System.out.println("Zahl wurde eingeben.");
        }
        else {
            System.out.println("Keine zahl!");
            System.out.println("Wirklich keine Zahl!");
        }



        System.out.println("Grosse ist: " + groesse);
    }
}
