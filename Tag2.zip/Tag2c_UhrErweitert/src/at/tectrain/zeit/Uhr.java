package at.tectrain.zeit;

public class Uhr {

    // konstante. sollte immer static und final sein!
    public static final int MAX_STUNDE = 24;
    public static final int MAX_MINUTE = 60;

    // ein statisches Attribut. Existiert genau 1mal! --> Existiert NICHT pro Objekt
    // klassenattribut = statisches attribut
    private static int uhrObjectCounter = 0;

    // Ist ein Instanzattribut. Existiert pro angelegten Objekt.
    private int stunde;
    // Ist ein Instanzattribut.
    private int minute;

    /**
     * Constructor ohne parameter.
     * Wird automatisch erzeugt falls kein anderer Constructor existiert.
     * = Default Constructor
     */
    public Uhr() {
        // man darf auch als erstes gleich einen anderen Constructor aufrufen.
        // hochzaehlen von uhrObjectCounter nicht notwendig, da es durch den this(...) Aufruf erledigt wird.
        this(12, 0);
        //this.stunde = 12;
        //this.minute = 0;
    }

    /**
     * Constructor mit Parameter
     * @param stunde
     * @param minute
     */
    public Uhr(int stunde, int minute) {
        ++uhrObjectCounter; // +1 da ein neues objekt angelegt wurde.
        this.stunde = stunde;
        this.minute = minute;
    }

    /**
     * Copy constructor
     * @param other
     */
    public Uhr(Uhr other) {
        // verwenden hier gleich wieder denn anderen constructor,
        // wo bereits der counter erhoeht wird.
        this(other.stunde, other.minute);
    }

    public static int getUhrObjectCounter() {
        // in einer statischen methode gibt es keine this referenz
        // --> zugriff auf stunde und minute waere hier nicht moeglich.
        return uhrObjectCounter;
    }

    /**
     * Zum Setzen der Stunde
     * @param stunde
     */
    public void setStunde(int stunde) {
        this.stunde = stunde;
    }

    /**
     * Getter Methode. Liefert die Stunde
     * Ist eine Instanzmethode.
     * @return Liefert die Stunde.
     */
    public int getStunde() {
        return stunde;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public void uhrzeitEinstellen(int stunde, int minute) {
        if (stunde < 0 || stunde >= MAX_STUNDE) {
            throw new IllegalArgumentException("stunde " + stunde +
                    " nicht erlaubt");
        }
        if (minute < 0 || minute >= MAX_MINUTE) {
            throw new IllegalArgumentException("minute " + minute +
                    " nicht erlaubt");
        }
        this.stunde = stunde;
        this.minute = minute;
    }
    /**
     * Gibt die Uhrzeit aus. Es handelt sich um eine
     * Instanzmethode (also um keine statische Methode).
     * --> es gibt ein dazugehoeriges Objekt.
     * Zugriff per this-Referenz dadurch moeglich.
     */
    public void ausgabe() {
        // der Zugriff auf nicht statische Attribute erfolgt
        // ueber die this Referenz.
        System.out.printf("%02d:%02d\n",
                stunde, // ist dasselbe wie this.stunde
                this.minute);
    }

    public boolean isEqual(Uhr other) {
        if (this == other) {
            // wenns ein und das selbe object ist, dann kann der inhalt nur gleich sein
            // speicheradressen bzw. speicherstelle werden verglichen aber nicht der inhalt
            return true;
        }
        // --> sind unterschiedliche objekte. aber der inhalt kann trotzdem gleich sein
        if (this.stunde == other.stunde && this.minute == other.minute) {
            return true;
        }
        return false;
    }
}
