package at.tectrain.helper;

public class Helper {

    /**
     * Ueberprueft ob eine Zahl eine Primzahl ist.
     *
     * @param zahl Zahl die ueberprueft wird.
     * @return Liefert true wenn es sich um eine Primzahl handelt. Ansonst false.
     */
    public static boolean isPrimzahl(long zahl) {
        if (zahl <= 1) {
            return false;
        }
        // --> kann nur >= 1 sein
        if (zahl == 2) {
            // --> einzig gerade primzahl
            return true;
        }
        if (zahl % 2 == 0) {
            // --> ist eine gerade zahl aber nicht die zahl 2
            return false;
        }
        // --> nur noch zahl >= 1 und nur ungerade moeglich
        for (long aktZahl = 3; aktZahl < zahl / 2; aktZahl += 2) {
            if (zahl % aktZahl == 0) {
                // zahl ist durch eine zahl (aktZahl) teilbar
                // --> ist keine Primzahl
                return false;
            }
        }
        // --> kann nur eine Primzahl sein
        return true;
    }

    // Diese Variante hat mehr Verschachtelungen --> evt schwieriger zu Lesen.
    public static boolean isPrimzahlV2(long zahl) {
        if (zahl > 1) {
            // --> nur dann ist eine primzahl moeglich
            if (zahl == 2) {
                // --> einzig gerade primzahl
                return true;
            }
            if (zahl % 2 != 0) {
                // --> ist eine ungerade zahl --> koennte eine primzahl sein
                // --> nur noch zahl >= 1 und nur ungerade moeglich
                for (long aktZahl = 3; aktZahl < zahl / 2; aktZahl += 2) {
                    if (zahl % aktZahl == 0) {
                        // zahl ist durch eine zahl (aktZahl) teilbar
                        // --> ist keine Primzahl
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }
}
