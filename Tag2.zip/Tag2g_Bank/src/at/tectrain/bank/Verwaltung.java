package at.tectrain.bank;

public class Verwaltung {
    // mehrere Bankkonten verwalten.
    // --> array das alle konten haelt
    // konto hinzufuegen

    private Bankkonto [] konten;
    private int naechsteFreiePosition = 0;

    /**
     * Konstruktor
     * @param maxAnzahl Maximale Anzahl der Konten
     */
    public Verwaltung(int maxAnzahl) {
        konten = new Bankkonto[maxAnzahl];
    }

    /**
     * Hinzufuegen eines Bankkontos
     * @param konto Bankkonto
     * @return True fuer erfolgreiches hinzufuegen. Sonst false.
     */
    public boolean kontoHinzufuegen(Bankkonto konto) {
        if (konto == null) {
            System.out.println("Err: Bankkonto objekt erwartet");
            return false;
        }
        if (naechsteFreiePosition == konten.length) {
            System.out.println("Err: Alle Konten belegt");
            return false;
        }
        konten[naechsteFreiePosition] = konto;
        ++naechsteFreiePosition;
        return true;
    }

    /**
     *
     * @param kontonummerSender
     * @param kontonummerEmpfaenger
     * @param betrag
     * @return True wenn Ueberweisung erfolgreich war. Sonst false.
     */
    public boolean ueberweisen(int kontonummerSender,
                               int kontonummerEmpfaenger,
                               double betrag) {
        Bankkonto sender = suche(kontonummerSender);
        Bankkonto empfaenger = suche(kontonummerEmpfaenger);
        if (sender == null || empfaenger == null) {
            System.out.println("Sender und/oder Empfaenger nicht gefunden.");
            return false;
        }
        // --> sender und empfaenger gefunden
        if (!sender.abbuchen(betrag)) {
            return false;
        }
        if (!empfaenger.einzahlen(betrag)) {
            sender.einzahlen(betrag);
            return false;
        }
        // --> alles hat funktioniert
        return true;
    }

    @Override
    public String toString() {
        String s = "*** Alle Konten ***\n";
        for (Bankkonto konto : konten) {
            // hier wird automatisch toString() aufgerufen falls konto
            // nicht null ist. Falls null dann "null" hinzugefuegt.
            s += konto;
            s += "\n";
        }
        return s;
    }

    /**
     *
     * @param kontonummer
     * @return Return object if found or null if not found.
     */
    private Bankkonto suche(int kontonummer) {
        for (Bankkonto konto : konten) {
            if (konto == null) {
                break;
            }
            if (konto.getKontonummer() == kontonummer) {
                return konto;
            }
        }
        return null;
    }
}
