package at.tectrain.hunde;

// Hund erbt von der Klasse Object da er nicht von einer anderen Klasse erbt.
// (extends Object muss nicht extra angegeben werden)
public abstract class Hund {

    private String name;
    // hundemarke bzw. chip-id
    private int chipId;

    public Hund() {
        name = "nobody";
        chipId = -1;
    }

    public Hund(String name, int chipId) {
        this.name = name;
        this.chipId = chipId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getChipId() {
        return chipId;
    }

    public void setChipId(int chipId) {
        this.chipId = chipId;
    }

    public abstract void zeigeTrick();

    @Override
    public String toString() {
        // mit getClass() bekomme ich ein Objekt zum verwendeten Typ/Klasse.
        return getClass().getSimpleName() + ": name: " + name + ", chip-id: " + chipId;
    }
}
