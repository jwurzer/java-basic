package at.tectrain.hunde;

public class Dackel extends AbstractHund {

    @Override
    public void zeigeTrick() {
        System.out.println("Wuff Wuff");
    }
}
