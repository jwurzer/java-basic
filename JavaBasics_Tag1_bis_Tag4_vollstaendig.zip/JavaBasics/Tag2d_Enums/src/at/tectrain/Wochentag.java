package at.tectrain;

public enum Wochentag {
    MONTAG(true, "Wochenbeginn"),
    DIENSTAG(true, "Geht schon"),
    MITTWOCH(true, "Wochenteilung"),
    DONNERSTAG(true, "Fast vorbei"),
    FREITAG(true, "Wirklich fast vorbei"),
    SAMSTAG(false, "Endlich frei"),
    SONNTAG(false, "Erholung");

    private final boolean arbeitstag;
    private final String beschreibung;

    private Wochentag(boolean arbeitstag, String beschreibung) {
        this.arbeitstag = arbeitstag;
        this.beschreibung = beschreibung;
    }

    public boolean isArbeitstag() {
        return arbeitstag;
    }

    public String getBeschreibung() {
        return beschreibung;
    }
}
