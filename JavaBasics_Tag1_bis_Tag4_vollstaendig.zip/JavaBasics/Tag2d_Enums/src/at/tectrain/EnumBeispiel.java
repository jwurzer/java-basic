package at.tectrain;

public class EnumBeispiel {

    static void printInfos(Wochentag tag) {
        System.out.println("ordnungszahl: " + tag.ordinal() + ", name: " + tag.name() +
                ", arbeitstag: " + tag.isArbeitstag() + ", beschreibung: " + tag.getBeschreibung());
        switch (tag) {
            case SAMSTAG, SONNTAG -> System.out.println("FEIERTAG!!!!");
            default -> System.out.println("nicht so ein toller tag :-(");
        }
    }

    public static void main(String[] args) {

        Wochentag tag1 = Wochentag.MONTAG;

        Wochentag tag2 = Wochentag.MITTWOCH;

        printInfos(tag2);
        printInfos(Wochentag.DONNERSTAG);

        System.out.println("donnserstag: " + Wochentag.DONNERSTAG.getBeschreibung());

        // enum konstanten darf ich direkt per referenz miteinander vergleichen, da es
        // fuer eine konstante nicht mehr objekte geben darf. (z.b. fuer den MITTWOCH kann es keine zwei objekte geben,
        // sondern es kann nur mehrere referenzen geben die auf den mittwoch verweisen.)
        if (tag1 == tag2) {
            System.out.println("sind gleiche tage");
        }
        else {
            System.out.println("sind unterschiedliche tage");
        }
    }
}
