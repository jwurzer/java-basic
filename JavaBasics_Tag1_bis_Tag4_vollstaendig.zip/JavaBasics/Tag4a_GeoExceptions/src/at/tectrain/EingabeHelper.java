package at.tectrain;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class EingabeHelper {

    // eine Methode zum Einlesen eines double-Werts

    /**
     * Ein double Wert wird mit dem Scanner eingelesen.
     *
     * @param eingabe Scanner fuer die Eingabe
     * @param beschreibung Wird beim Eingabeprompt verwendet
     * @return Eingelesenen Wert
     */
    public static double doubleEinlesen(Scanner eingabe, String beschreibung) {

        while (true) {
            System.out.print(beschreibung + "> ");
            try {
                return eingabe.nextDouble();
            }
            catch (InputMismatchException e) {
                System.out.println("Keine gueltige Eingabe. Bitte Eingabe wiederholen.");
                // ungueltige Eingabe einlesen als String und verwerfen
                // --> naechste Eingabe bekommt einen neuen "Text"
                eingabe.next();
            }
            catch (NoSuchElementException e) {
                throw new NoSuchElementException("Eingabe kann nicht durchgefuehrt werden", e);
            }
        }
    }
}
