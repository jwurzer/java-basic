package at.tectrain;

import at.tectrain.zeit.Helper;
import at.tectrain.zeit.Uhr;

import java.util.Locale;

public class UhrenBeispielErweitert {

    public static void main(String[] args) {

        System.out.println("counter: " + Uhr.getUhrObjectCounter());

        Uhr zeit1 = new Uhr(10, 20);
        Uhr zeit2 = new Uhr();

        System.out.println("counter: " + Uhr.getUhrObjectCounter());

        Uhr zeit3;

        zeit3 = null;
        //zeit3.ausgabe();

        zeit3 = new Uhr(zeit1);
        System.out.println("counter: " + Uhr.getUhrObjectCounter());

        if (zeit3 == zeit1) {
            System.out.println("zeit3 u zeit1 sind das selbe objekt");
        }
        if (zeit3.isEqual(zeit1)) {
            System.out.println("zeit3 und zeit1 sind gleich");
        }

        Uhr zeit4 = zeit2;
        // hier wird 3 und nicht 4 ausgegeben, da kein neues objekt angelegt wird.
        System.out.println("counter: " + Uhr.getUhrObjectCounter());

        if (zeit4 == zeit2) {
            System.out.println("ein und das selbe objekt");
        }
        if (zeit4.isEqual(zeit2)) {
            System.out.println("sind gleich");
        }
        zeit1.ausgabe();
        zeit2.ausgabe();

        zeit1.uhrzeitEinstellen(13, 10);

        zeit2.uhrzeitEinstellen(9, 5);

        zeit4.setMinute(55);

        //Helper.resetUhrzeit(zeit1);
        //Helper.resetUhrzeitV2(zeit1);
        zeit1 = Helper.resetUhrzeitV3();

        //Helper.resetUhrzeit(zeit4);
        zeit4 = Helper.resetUhrzeitV3();

        zeit1.ausgabe();
        zeit2.ausgabe();
        zeit3.ausgabe();

        System.out.println("counter: " + Uhr.getUhrObjectCounter());

    }
}
