package at.tectrain.zeit;

public class Uhr {

    // Ist ein Instanzattribut. Existiert pro angelegten Objekt.
    private int stunde;
    // Ist ein Instanzattribut.
    private int minute;

    /**
     * Constructor ohne parameter.
     * Wird automatisch erzeugt falls kein anderer Constructor existiert.
     * = Default Constructor
     */
    public Uhr() {
        // man darf auch als erstes gleich einen anderen Constructor aufrufen.
        this(12, 0);
        //this.stunde = 12;
        //this.minute = 0;
    }

    /**
     * Constructor mit Parameter
     * @param stunde
     * @param minute
     */
    public Uhr(int stunde, int minute) {
        this.stunde = stunde;
        this.minute = minute;
    }

    /**
     * Copy constructor
     * @param other
     */
    public Uhr(Uhr other) {
        // habe nun Zugriff auch zwei Objekte
        // 1) auf this-Objekt das Initialisiert werden soll
        // 2) auf other-Objekt von dem die Werte uebernommen werden sollen
        this.stunde = other.stunde;
        this.minute = other.minute;
    }
    /**
     * Zum Setzen der Stunde
     * @param stunde
     */
    public void setStunde(int stunde) {
        this.stunde = stunde;
    }

    /**
     * Getter Methode. Liefert die Stunde
     * Ist eine Instanzmethode.
     * @return Liefert die Stunde.
     */
    public int getStunde() {
        return stunde;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public void uhrzeitEinstellen(int stunde, int minute) {
        if (stunde < 0 || stunde >= 24) {
            throw new IllegalArgumentException("stunde " + stunde +
                    " nicht erlaubt");
        }
        if (minute < 0 || minute >= 60) {
            throw new IllegalArgumentException("minute " + minute +
                    " nicht erlaubt");
        }
        this.stunde = stunde;
        this.minute = minute;
    }
    /**
     * Gibt die Uhrzeit aus. Es handelt sich um eine
     * Instanzmethode (also um keine statische Methode).
     * --> es gibt ein dazugehoeriges Objekt.
     * Zugriff per this-Referenz dadurch moeglich.
     */
    public void ausgabe() {
        // der Zugriff auf nicht statische Attribute erfolgt
        // ueber die this Referenz.
        System.out.printf("%02d:%02d\n",
                stunde, // ist dasselbe wie this.stunde
                this.minute);
    }
}
