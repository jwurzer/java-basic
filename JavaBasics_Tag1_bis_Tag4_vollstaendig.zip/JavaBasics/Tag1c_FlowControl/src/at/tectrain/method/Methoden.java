package at.tectrain.method;

public class Methoden {

    static int summe(int a, int b) {
        System.out.println("summe - int - 2 args");
        return a + b;
    }

    static int summe(int a, int b, int c) {
        System.out.println("summe - int - 3 args");
        return a + b + c;
    }

    static double summe(double a, double b) {
        System.out.println("summe - double - 2 args");
        return a + b;
    }

    static int doSomething(int a, int b) {
        ++a;
        b += 2;
        return a + b;
    }

    static void multArray2x(float[] nummern) {
        for (int i = 0; i < nummern.length; ++i) {
            nummern[i] *= 2.0f;
        }
    }

    static void ausgabe(float[] nummern) {
        System.out.println("*** ausgabe ***");
        for (float nr : nummern) {
            System.out.println(nr);
        }
    }

    public static void main(String[] args) {
        int x = 5, y = 7;
        int z;
        double d1;

        z = summe(x, y);
        System.out.println(z);

        z = summe(x, y, 9);
        System.out.println(z);

        // Klassenname hier nicht notwendig
        Methoden.summe(5, 7); // ruft int version auf
        summe(5.0, 7.0); // ruft double version auf
        // hier wird die double-version verwendet, da 7 als int implizit in einen double gecastet wird.
        summe(5.0, 7);

        z = doSomething(x, y);
        System.out.println(z + " " + x + " " + y);

        float [] nums = new float[] {3.7f, 2.5f, 1.3f};
        ausgabe(nums);
        multArray2x(nums);
        ausgabe(nums);

        float summe = MathEx.sum(nums);
    }

}
