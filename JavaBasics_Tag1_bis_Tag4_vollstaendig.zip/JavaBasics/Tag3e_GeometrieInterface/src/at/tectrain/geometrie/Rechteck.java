package at.tectrain.geometrie;

public class Rechteck implements Geometrie {
    private double laenge;
    private double breite;

    public Rechteck(double laenge, double breite) {
        this.laenge = laenge;
        this.breite = breite;
    }

    public double getLaenge() {
        return laenge;
    }

    public double getBreite() {
        return breite;
    }

    @Override
    public double umfang() {
        return (laenge + breite) * 2.0;
    }

    @Override
    public double flaeche() {
        return laenge * breite;
    }

    @Override
    public String toString() {
        return "Rechteck{" +
                "laenge=" + laenge +
                ", breite=" + breite +
                '}';
    }
}
