package at.tectrain;

import at.tectrain.geometrie.Geometrie;
import at.tectrain.geometrie.Kreis;
import at.tectrain.geometrie.Rechteck;

public class GeoBeispiel {

    public static void main(String[] args) {

        Geometrie g1 = new Rechteck(10.0, 3.5);
        Geometrie g2 = new Kreis(3.3);
        //Geometrie g3 = new Geometrie(); // nicht erlaubt! da es sich um ein interface handelt

        //System.out.println("laenge: " + g1.getLaenge());

        System.out.println("umfang von g1: " + g1.umfang());
        System.out.println("umfang von g2: " + g2.umfang());

        System.out.println(g1);
        System.out.println(g2);
    }
}
