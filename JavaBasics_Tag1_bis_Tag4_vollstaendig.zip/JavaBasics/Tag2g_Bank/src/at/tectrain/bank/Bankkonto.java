package at.tectrain.bank;

public class Bankkonto {

    // 3 attribute
    // - eine kontonummer (int als typ genuegt)
    // - kontoinhaber (string)
    // - kontostand (double)
    private int kontonummer;
    private String inhaber;
    private double kontostand;

    // konstruktor
    // - ohne parameter
    // - mit 3 parameter fuer die attribute


    public Bankkonto() {
        kontonummer = 0;
        inhaber = "nobody";
        kontostand = 0.0;
    }

    public Bankkonto(int kontonummer, String inhaber, double kontostand) {
        this.kontonummer = kontonummer;
        this.inhaber = inhaber;
        this.kontostand = kontostand;
    }

    // get- und setter methoden

    public int getKontonummer() {
        return kontonummer;
    }

    public void setKontonummer(int kontonummer) {
        this.kontonummer = kontonummer;
    }

    public String getInhaber() {
        return inhaber;
    }

    public void setInhaber(String inhaber) {
        this.inhaber = inhaber;
    }

    public double getKontostand() {
        return kontostand;
    }

    public void setKontostand(double kontostand) {
        this.kontostand = kontostand;
    }


    // eine methode fuer die ausgabe
    public void ausgabe() {
        System.out.println("nr: " + kontonummer + ", inhaber " + inhaber + ", kontostand " + kontostand);
    }

    // eine methode zum abbuchen eines betrags
    public boolean abbuchen(double betrag) {
        if (betrag < 0.0) {
            return false;
        }
        if (betrag > kontostand) {
            return false;
        }
        kontostand -= betrag;
        return true;
    }

    public boolean einzahlen(double betrag) {
        if (betrag < 0.0) {
            return false;
        }
        kontostand += betrag;
        return true;
    }

    @Override
    public String toString() {
        return "nr: " + kontonummer + ", inhaber " + inhaber + ", kontostand " + kontostand;
    }
}
