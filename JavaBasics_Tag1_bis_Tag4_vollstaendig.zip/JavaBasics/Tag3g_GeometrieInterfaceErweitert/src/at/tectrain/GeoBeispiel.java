package at.tectrain;

import at.tectrain.geometrie.Geometrie;
import at.tectrain.geometrie.Kreis;
import at.tectrain.geometrie.Rechteck;
import at.tectrain.geometrie.RechtwinkeligesDreieck;

import java.util.ArrayList;

public class GeoBeispiel {

    public static void main(String[] args) {

        Geometrie g1 = new Rechteck(10.0, 3.5);
        Geometrie g2 = new Kreis(3.3);
        //Geometrie g3 = new Geometrie(); // nicht erlaubt! da es sich um ein interface handelt

        //System.out.println("laenge: " + g1.getLaenge());

        g1.umfangUndFlaecheAusgeben();
        g2.umfangUndFlaecheAusgeben();

        System.out.println(g1);
        System.out.println(g2);

        // liste von geometrien
        ArrayList<Geometrie> geometrien = new ArrayList<Geometrie>();

        // fuegen die geometrien hinzu
        geometrien.add(g1);
        geometrien.add(g2);
        geometrien.add(new Rechteck(7.0, 4.3));
        geometrien.add(new Kreis(17.0));
        geometrien.add(new RechtwinkeligesDreieck(5.0, 3.4));
        geometrien.add(new RechtwinkeligesDreieck(7.0, 1.4));

        System.out.println("*** alle geometrien ***");
        for (Geometrie geo : geometrien) {
            System.out.println(geo);
        }

        System.out.println("*** alle umfaenge und flaechen ***");
        for (Geometrie g : geometrien) {
            g.umfangUndFlaecheAusgeben();
        }

        System.out.println("*** alle rechtecke per instanceof ***");
        for (Geometrie g : geometrien) {
            // ueberprueft ob ein Rechteck enthalten ist --> auch ein RechtwinkeligesDreieck wird ausgegeben
            if (g instanceof Rechteck r) {
                System.out.println(r);
            }
        }

        System.out.println("*** alle rechtecke per getClass() ***");
        for (Geometrie g : geometrien) {
            if (g.getClass() == Rechteck.class) {
                System.out.println(g);
            }
        }
    }
}
