package at.tectrain.map;

import at.tectrain.PersonalNr;

import java.util.*;

public class MapBeispiel {
    public static void main(String[] args) {


        // PersonalNr muss Comparable impl haben
        //Map<PersonalNr, String> personen = new TreeMap<>();

        // PersonalNr muss equals() und hashCode() ueberschrieben haben
        Map<PersonalNr, String> personen = new HashMap<>();

        personen.put(new PersonalNr(7, 10), "Alice");
        personen.put(new PersonalNr(7, 10), "Bob");
        personen.put(new PersonalNr(1, 3), "Susi");
        personen.put(new PersonalNr(5, 1), "Max");
        personen.put(new PersonalNr(3, 3), "Susi");
        personen.put(new PersonalNr(15, 1), "Franz");

        String suche = personen.get(new PersonalNr(7, 10));
        if (suche != null) {
            // ungleich null wenn gefunden
            System.out.println(suche + " wurde gefunden");
        }

        System.out.println("*** ausgabe per keySet ***");
        // hier bekomme ich alle schluessel
        Set<PersonalNr> keys = personen.keySet();
        for (PersonalNr key : keys) {
            // fuer jedes element wird neu mit get() gesucht
            System.out.println(personen.get(key));
        }

        System.out.println("*** ausgabe per entrySet ***");
        Set<Map.Entry<PersonalNr, String>> entrySet = personen.entrySet();
        for (Map.Entry<PersonalNr, String> entry : entrySet) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        System.out.println("*** ausgabe per entrySet ***");
        // einfacher ist:
        for (Map.Entry<PersonalNr, String> entry : personen.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        System.out.println("*** ausgabe per entrySet ***");
        // noch einfacher ist:
        for (var entry : personen.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
