package at.tectrain.set;

import at.tectrain.PersonalNr;

import java.util.*;

public class SetPersonalNrBeispiel {

    public static void main(String[] args) {

        // Damit PersonalNr bei einem TreeSet verwendet werden kann, muss das Interface Comparable von PersonalNr
        // implementiert werden, oder es wird ein passender Comparator zur Verfuegung gestellt.
        //Set<PersonalNr> numbers = new TreeSet<>();

        // HashSet verwendet hashCode() und equals(). Comparable wird nicht verwendet (nicht notwendig)
        // --> Diese Methoden muessen richtig implementiert sein.
        Set<PersonalNr> numbers = new HashSet<>();

        numbers.add(new PersonalNr(7, 10));
        numbers.add(new PersonalNr(3, 5));
        numbers.add(new PersonalNr(3, 1));
        numbers.add(new PersonalNr(7, 10));

        for (PersonalNr nr : numbers) {
            System.out.println(nr + ", hash: " + nr.hashCode() + ", mod: " + (nr.hashCode() % 16));
        }
    }
}
