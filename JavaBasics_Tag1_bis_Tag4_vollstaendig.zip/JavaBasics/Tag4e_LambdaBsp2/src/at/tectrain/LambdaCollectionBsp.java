package at.tectrain;

import java.util.*;
import java.util.function.Consumer;

public class LambdaCollectionBsp {
    public static void main(String[] args) {

        List<String> namen = new ArrayList<>();
        namen.add("Alice");
        namen.add("Bob");
        namen.add("Susi");

//        Consumer<String> stringConsumer = new Consumer<String>() {
//            @Override
//            public void accept(String s) {
//                System.out.println("**** " + s + " ****");
//            }
//        };

        // lambda expression
        Consumer<String> stringConsumer = str -> System.out.println("**** " + str + " ****");

        namen.forEach(stringConsumer);

        namen.forEach(str -> System.out.println("#### " + str + " ####"));

    }
}
