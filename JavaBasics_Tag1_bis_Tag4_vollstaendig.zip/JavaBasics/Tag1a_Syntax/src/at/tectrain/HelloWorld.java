package at.tectrain;

public class HelloWorld {

    public static void main(String[] args) {

        System.out.println("Hello World");
        System.out.println("Das ist ein Test");
    }
}
