package at.tectrain;

public class Position2D<T extends Number & Comparable<T>> {
    private T x;
    private T y;

    public Position2D(T x, T y) {
        this.x = x;
        this.y = y;
    }

    public T getX() {
        return x;
    }

    public void setX(T x) {
        this.x = x;
    }

    public T getY() {
        return y;
    }

    public void setY(T y) {
        this.y = y;
    }

    /**
     * Vergleich x von uebergebener Position other mit dem x von this
     * @return True wenn this.x groesser als other.x ist. Sonst false.
     */
    public boolean istXGroesser(Position2D<T> other) {
        return this.x.compareTo(other.x) > 0;
    }

    public double getXPlusY() {
        return this.x.doubleValue() + this.y.doubleValue();
    }

    @Override
    public String toString() {
        return "Position2D{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
