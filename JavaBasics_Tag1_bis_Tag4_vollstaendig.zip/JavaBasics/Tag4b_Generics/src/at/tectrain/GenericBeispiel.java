package at.tectrain;

import java.util.Comparator;

public class GenericBeispiel {

    public static void main(String[] args) {

        //Position2D<Float> p1 = new Position2D<Float>(3.5f, 4.1f);
        // kann sich per typinferenz den Type sich selbst herleiten
        Position2D<Float> p1 = new Position2D<>(3.5f, 4.1f);
        System.out.println(p1);

        Position2D<Integer> p2 = new Position2D<>(3, 7);
        // gleich wie:
        //Position2D<Integer> p2 = new Position2D<>(
        //        Integer.valueOf(3), Integer.valueOf(7));

        Position2D<Integer> p3 = new Position2D<>(-3, 17);

        // funktioniert nicht, da sie unterschiedlich parametrisiert sind.
        //if (p1.istXGroesser(p2)) {
        //}
        // fuer p3 und p2 kein Problem, da beide gleich parametrisiert sind.
        if (p3.istXGroesser(p2)) {
        }

        System.out.println("x + y = " + p2.getXPlusY());
        System.out.println(p2);

        // ein raw type sollte nicht verwendet werden.
        Position2D px = new Position2D(4, 1);

        // ohne weitere Einschraenkung auch mit String moeglich
        //Position2D<String> p3 = new Position2D<>("eins", "minus vier");

        Comparable x;
        Comparator y;
    }
}
