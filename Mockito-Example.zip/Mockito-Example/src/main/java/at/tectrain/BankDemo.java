package at.tectrain;

import at.tectrain.container.BankService;
import at.tectrain.container.BankkontoContainer;
import at.tectrain.container.BankkontoContainerImpl;
import at.tectrain.model.Bankkonto;

public class BankDemo {

	public static void main(String[] args) {

		//BankkontoContainer konten = new BankkontoContainerImpl();
		//BankService service = new BankService(konten);
		
		// so waere is auch ok
		BankService service = new BankService(new BankkontoContainerImpl());
		
		service.kontoHinzufuegen(new Bankkonto("Alice", 300));
		service.kontoHinzufuegen(new Bankkonto("Bob", 700));
		service.kontoHinzufuegen(new Bankkonto("Franz", 400));
		service.alleAusgeben();
		
		service.ueberweisen(11, 12, 200);
		service.alleAusgeben();
	}

}
