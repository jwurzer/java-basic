package at.tectrain.container;

import at.tectrain.model.BankException;
import at.tectrain.model.Bankkonto;

public class BankService {
	private BankkontoContainer kontoContainer;

	public BankService(BankkontoContainer kontoContainer) {
		this.kontoContainer = kontoContainer;
	}
	
	public void kontoHinzufuegen(Bankkonto konto) throws BankException {
		kontoContainer.hinzufuegen(konto);
	}

	public Bankkonto findeKonto(int kontoNr) throws BankException {
		return kontoContainer.suche(kontoNr);
	}
	
	/**
	 * 
	 * @param zahlerKontoNr Schuldner
	 * @param empfaengerKontoNr Zahlungsempfaenger
	 * @param betrag
	 * @throws BankException
	 */
	public void ueberweisen(int zahlerKontoNr,
			int empfaengerKontoNr, double betrag) throws BankException {
		if (zahlerKontoNr == empfaengerKontoNr) {
			throw new BankException("Zahler und Empfaenger sind gleich");
		}
		Bankkonto zahler = kontoContainer.suche(zahlerKontoNr);
		Bankkonto empfaenger = kontoContainer.suche(empfaengerKontoNr);
		if (zahler.getKontostand() < betrag) {
			throw new BankException("Zahler hat zu wenig Geld");
		}
		zahler.abheben(betrag);
		empfaenger.einzahlen(betrag);
	}
	
	public void einzahlen(int kontoNr, double betrag) {
		// get account and deposit the amount
		Bankkonto konto = kontoContainer.suche(kontoNr);
		konto.einzahlen(betrag);
		// update account in repository
		kontoContainer.update(konto);
	}
	
	public void alleAusgeben() {
		System.out.println("*** Alle Bankkonten ***");
		kontoContainer.alleBankkonten()
				.forEach(konto -> System.out.println(konto));
	}
	
	public double kontoAufloesen(int kontoNr) {
		Bankkonto konto = kontoContainer.suche(kontoNr);
		if (konto.getKontostand() < 5.0) {
			throw new BankException("Konto mit Nr " + kontoNr +
					" kann nicht geschlossen werden - Kontostand reicht nicht");
		}
		konto.abheben(5.0);
		kontoContainer.entfernen(kontoNr);
		return konto.getKontostand();
	}
}
