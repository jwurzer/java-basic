package at.tectrain.geometrie;

// Klasse ist abstract --> kann ich kein Objekt anlegen.
public abstract class Geometrie {

    public abstract double umfang();

    public abstract double flaeche();
}
