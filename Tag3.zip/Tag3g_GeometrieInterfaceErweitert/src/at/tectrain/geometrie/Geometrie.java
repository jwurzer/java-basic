package at.tectrain.geometrie;

// Klasse ist abstract --> kann ich kein Objekt anlegen.
public interface Geometrie {

    // Konstanten sind in einem interface erlaubt!
    // sind automatisch public static final.
    // --> int X = 5; waere eine Konstante und kein Instanzattribut!!!!!
    // Instanzattribute sind nicht moeglich!!!!!

    // in einem interface sind abstrakte Methoden automatisch public und abstract.
    double umfang();

    public abstract double flaeche();

    default void umfangUndFlaecheAusgeben() {
        System.out.println("umfang: " + umfang() + ", flaeche: " + flaeche());
    }

    default String umfangUndFlaecheAusgebenAlsString() {
        return "umfang: " + umfang() + ", flaeche: " + flaeche();
    }
}
