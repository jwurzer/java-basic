package at.tectrain.geometrie;

public class RechtwinkeligesDreieck extends Rechteck {

    public RechtwinkeligesDreieck(double laenge, double breite) {
        super(laenge, breite);
    }

    @Override
    public double umfang() {
        return laenge + breite + Math.sqrt(laenge * laenge + breite * breite);
    }

    @Override
    public double flaeche() {
        return super.flaeche() * 0.5;
    }

    @Override
    public String toString() {
        return "RechtwinkeligesDreieck{" +
                "laenge=" + laenge +
                ", breite=" + breite +
                '}';
    }
}
