package at.tectrain;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ExceptionBeispiel {
    public static void main(String[] args) {


        Scanner eingabe = new Scanner(System.in);

        try {
            double nummer = eingabe.nextDouble();
            System.out.println("Eingabe war: " + nummer);
            //return; // selbst bei einem return wuerde noch zuvor der finally block ausgefuehrt werden.
        }
        catch (InputMismatchException e) {
            e.printStackTrace();
            //e.printStackTrace(System.out);
        }
        catch (NoSuchElementException e) {
            // z.b. ausgeloest mit STRG+D zum Schliessen des Standard Inputs
            e.printStackTrace(System.out);
        }
        finally {
            System.out.println("WIRD IMMER AUSGEFUEHRT!");
            eingabe.close();
        }

        System.out.println("Good bye!!!!");
    }
}
