package at.tectrain;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class FilePathBeispiel {

    public static void main(String[] args) {

        File f1 = new File("demo.txt");

        if (f1.exists()) {
            System.out.println("existiert");
        }

        if (f1.isFile()) {
            System.out.println("regulaere datei");
        }

        if (f1.isDirectory()) {
            System.out.println("ist ein verzeichnis");
        }

        // . = aktuelles arbeitsverzeichnis
        File dir = new File(".");
        if (dir.isDirectory()) {
            System.out.println("ist ein verzeichnis");
            File[] dateien = dir.listFiles();
            for (File f : dateien) {
                System.out.println("name: " + f.getName() + ", dir: " + f.isDirectory());
            }
        }

        // File.pathSeparator ist das Trennzeichen fuer die PATH umgeb.var.
        System.out.println(File.pathSeparator);

        // trennzeichen zwischen verzeichnissen in einem pfad
        File f2 = new File("subdir" + File.separator + "test.txt");

        File f3 = new File("testdir");
        f3.mkdir(); // legt das verzeichnis an

        // auslesen einer Textdatei per Files.lines()
        System.out.println("===== demo.txt ====");
        Path filename = Path.of("demo.txt");
        try {
            Files.lines(filename).forEach(System.out::println);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // path --> file
        File f4 = filename.toFile();

        // file --> path
        Path p2 = f3.toPath();
        if (Files.isSymbolicLink(p2)) {
            System.out.println("ist ein sym link");
        }

    }
}
