package at.tectrain;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ReaderWriterBeispiel {

    /**
     * Schreibt in die Datei 'filename'.
     * Liest zeilenweise vom Scanner und schreibt diese in die Datei bis "quit" eingeben wird.
     * @param eingabe
     * @param filename
     */
    static void inDateiSchreiben(Scanner eingabe, String filename) {

        // FileWriter wird innerhalb von try (...) angelegt (try-with-resources).
        // --> close() wird immer zum Schluss aufgerufen.
        try (FileWriter fileWriter = new FileWriter(filename, StandardCharsets.UTF_8, true);
             BufferedWriter bufWriter = new BufferedWriter(fileWriter)) {

            String line;
            while ((line = eingabe.nextLine()) != null && !line.equals("quit")) {

                bufWriter.write(line);
                bufWriter.newLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void dateiEinlesenUndAusgeben(String filename) {

        //try (FileReader fr = new FileReader(filename, StandardCharsets.UTF_8);
        //     BufferedReader bufReader = new BufferedReader(fr)) {

        //try (BufferedReader bufReader = new BufferedReader(new FileReader(filename, StandardCharsets.UTF_8))) {

        // Ich kann auch aus einen InputStream einen Reader machen.
        // Nuetzlich wenn z.B. von einer Netzwerkverbindung gelesen wird und das Gelesene als Text zu lesen ist.
        try (FileInputStream fis = new FileInputStream(filename);
            InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
            BufferedReader bufReader = new BufferedReader(isr)) {

            String line;
            // zeile einlesen und anschliessend ueberprufen ob sie nicht null ist. wenn null --> EOF
            while ((line = bufReader.readLine()) != null) {
                System.out.println("Zeile: " + line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        //Scanner eingabe = new Scanner(System.in);
        //inDateiSchreiben(eingabe, "demo.txt");
        dateiEinlesenUndAusgeben("demo.txt");
    }
}
