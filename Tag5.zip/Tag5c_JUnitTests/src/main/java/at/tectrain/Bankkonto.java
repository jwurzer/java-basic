package at.tectrain;

public class Bankkonto {
	private static int nextKontoNr = 10;
	
	private int kontoNr;
	private String besitzer;
	private double kontostand;
	
	public Bankkonto(String besitzer, double kontostand) {
		this.kontoNr = nextKontoNr;
		++nextKontoNr;
		this.besitzer = besitzer;
		this.kontostand = kontostand;
	}

	public static int getNextKontoNr() {
		return nextKontoNr;
	}

	public int getKontoNr() {
		return kontoNr;
	}

	public String getBesitzer() {
		return besitzer;
	}

	
	public double getKontostand() {
		return kontostand;
	}

	public void einzahlen(double betrag) {
		if (betrag <= 0.0) {
			throw new IllegalArgumentException("Negative betrag: " + betrag);
		}
		kontostand += betrag;
	}
	
	public boolean abheben(double betrag) {
		if (betrag <= 0.0) {
			throw new IllegalArgumentException("Negative betrag: " + betrag);
		}
		if (betrag > kontostand) {
			return false;
		}
		kontostand -= betrag;
		return true;
	}

	@Override
	public String toString() {
		return "Bankkonto [kontoNr=" + kontoNr +
				", besitzer=" + besitzer +
				", kontostand=" + kontostand + "]";
	}
}
